document.addEventListener('DOMContentLoaded', () => {
    // Cyber Sound Generator (Web Audio API - Sci-Fi Click)
    function playCyberClick() {
        try {
            const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(300, audioCtx.currentTime + 0.05);

            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.05);

            osc.connect(gain);
            gain.connect(audioCtx.destination);

            osc.start();
            osc.stop(audioCtx.currentTime + 0.05);
        } catch (e) {
            // Audio context policy fallback
        }
    }

    // Pasang sound click ke semua tombol interaktif
    document.querySelectorAll('a, button').forEach(el => {
        el.addEventListener('click', playCyberClick);
    });

    // Hamburger Navigation Menu
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('nav-links');

    if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    }

    // Smooth Page Slide Transition
    const links = document.querySelectorAll('.nav-item, .btn-neon');
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            const targetUrl = link.getAttribute('href');
            if (targetUrl && targetUrl.includes('.html') && !targetUrl.startsWith('#')) {
                e.preventDefault();
                document.body.classList.add('page-exit');
                setTimeout(() => {
                    window.location.href = targetUrl;
                }, 450);
            }
        });
    });

    // Quick Filter Kategori Laptop
    const filterBtns = document.querySelectorAll('.filter-btn');
    const productCards = document.querySelectorAll('.card[data-category]');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filterValue = btn.getAttribute('data-filter');

            productCards.forEach(card => {
                if (filterValue === 'all' || card.getAttribute('data-category') === filterValue) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });

    // Modal Popup Detail Spesifikasi Produk
    const productModal = document.getElementById('productModal');
    const modalClose = document.getElementById('modalClose');
    const detailButtons = document.querySelectorAll('.btn-card');

    const modalTitle = document.getElementById('modalTitle');
    const modalPrice = document.getElementById('modalPrice');
    const modalSpecs = document.getElementById('modalSpecs');
    const modalActionBtn = document.getElementById('modalActionBtn');

    detailButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const title = btn.getAttribute('data-title');
            const price = btn.getAttribute('data-price');
            const specs = btn.getAttribute('data-specs');

            modalTitle.textContent = title;
            modalPrice.textContent = price;
            modalSpecs.textContent = specs;

            // Update link WhatsApp pemesanan dinamis
            modalActionBtn.onclick = () => {
                const message = encodeURIComponent(`Halo CoreLogic Technologies, saya tertarik untuk memesan unit ${title} seharga ${price}. Mohon informasi ketersediaannya.`);
                window.open(`https://wa.me/6281234567890?text=${message}`, '_blank');
            };

            productModal.classList.add('active');
        });
    });

    if (modalClose && productModal) {
        modalClose.addEventListener('click', () => {
            productModal.classList.remove('active');
        });

        productModal.addEventListener('click', (e) => {
            if (e.target === productModal) {
                productModal.classList.remove('active');
            }
        });
    }

    // Inisialisasi Canvas Hacker Background
    initHackerCanvas();
});

// Canvas Matrix / Hacker Code Stream Effect
function initHackerCanvas() {
    const canvas = document.getElementById('cyberCanvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const characters = '01CORELOGIC10ASUSROG18RTX4090010101XYZA9876543210#$%*';
    const fontSize = 14;
    const columns = Math.floor(canvas.width / fontSize);
    const drops = [];

    for (let i = 0; i < columns; i++) {
        drops[i] = Math.floor(Math.random() * -100);
    }

    function draw() {
        ctx.fillStyle = 'rgba(5, 11, 20, 0.15)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.font = `${fontSize}px monospace`;

        for (let i = 0; i < drops.length; i++) {
            const text = characters.charAt(Math.floor(Math.random() * characters.length));
            
            if (Math.random() > 0.88) {
                ctx.fillStyle = '#00ff66';
            } else {
                ctx.fillStyle = '#00f0ff';
            }

            ctx.fillText(text, i * fontSize, drops[i] * fontSize);

            if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                drops[i] = 0;
            }
            drops[i]++;
        }
    }

    setInterval(draw, 33);
}